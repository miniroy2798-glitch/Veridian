import React from 'react';
import { loginWithGoogle } from '../lib/firebase';
import { useAuth } from '../lib/AuthContext';
import { Navigate } from 'react-router-dom';
import { Shield } from 'lucide-react';

export default function Login() {
  const { user } = useAuth();
  
  if (user) {
    return <Navigate to="/" replace />;
  }

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
    } catch (err: any) {
      console.error(err);
      if (err?.code !== 'auth/cancelled-popup-request' && err?.code !== 'auth/popup-closed-by-user') {
        alert('Login failed. Please try again.');
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-[32px] p-10 shadow-sm flex flex-col items-center text-center border border-[#f0f0e8]">
        <div className="bg-[#f5f5f0] p-5 rounded-full mb-6 text-[#5A5A40]">
          <Shield size={48} />
        </div>
        <h1 className="font-serif italic text-4xl text-[#5A5A40] mb-3">Veridian</h1>
        <p className="text-[#8e8e8e] mb-10 text-sm">
          Secure, end-to-end encrypted messaging.
        </p>
        
        <button
          onClick={handleLogin}
          className="w-full bg-[#5A5A40] hover:bg-[#4a4a35] text-white font-medium py-4 px-6 rounded-full transition-colors flex items-center justify-center gap-2 shadow-sm"
        >
          Sign in with Google
        </button>
      </div>
    </div>
  );
}
