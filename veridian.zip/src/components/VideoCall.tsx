import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, addDoc, collection, onSnapshot, updateDoc, serverTimestamp, deleteDoc } from 'firebase/firestore';
import { Mic, MicOff, PhoneOff, Video, VideoOff } from 'lucide-react';

const servers = {
  iceServers: [
    { urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'] }
  ],
  iceCandidatePoolSize: 10,
};

export default function VideoCall({ 
  peerId, 
  onClose,
  existingCallId
}: { 
  chatId: string; 
  peerId: string; 
  onClose: () => void;
  existingCallId: string | null;
}) {
  const { user } = useAuth();
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const callDocRef = useRef<any>(null); // To clean up
  
  const [micState, setMicState] = useState(true);
  const [camState, setCamState] = useState(true);
  const [status, setStatus] = useState<string>('Connecting hardware...');

  useEffect(() => {
    let unsubs: (() => void)[] = [];

    const setupCall = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        localStreamRef.current = stream;
        if (localVideoRef.current) localVideoRef.current.srcObject = stream;
        
        const pc = new RTCPeerConnection(servers);
        pcRef.current = pc;
        
        // Push tracks from local stream to peer connection
        stream.getTracks().forEach((track) => {
          pc.addTrack(track, stream);
        });
        
        // Pull tracks from peer connection
        pc.ontrack = (event) => {
          event.streams[0].getTracks().forEach((track) => {
             if (remoteVideoRef.current && !remoteVideoRef.current.srcObject) {
                remoteVideoRef.current.srcObject = event.streams[0];
             }
          });
        };

        if (!existingCallId) {
           // -------- I am Caller --------
           setStatus('Calling...');
           const callDoc = doc(collection(db, 'calls'));
           callDocRef.current = callDoc;
           
           const offerCandidates = collection(callDoc, 'callerCandidates');
           const answerCandidates = collection(callDoc, 'calleeCandidates');

           pc.onicecandidate = (event) => {
             if (event.candidate) {
               addDoc(offerCandidates, { candidate: JSON.stringify(event.candidate.toJSON()) });
             }
           };

           const offerDescription = await pc.createOffer();
           await pc.setLocalDescription(offerDescription);

           await setDoc(callDoc, {
             callerId: user?.uid,
             calleeId: peerId,
             offer: JSON.stringify(offerDescription),
             status: 'calling',
             createdAt: serverTimestamp()
           });

           // Listen for answer
           const unsubDoc = onSnapshot(callDoc, (docSnap) => {
             const data = docSnap.data();
             if (!pc.currentRemoteDescription && data?.answer) {
               const answerDescription = new RTCSessionDescription(JSON.parse(data.answer));
               pc.setRemoteDescription(answerDescription);
               setStatus('Connected');
             }
             if (data?.status === 'ended') {
               handleHangup();
             }
           });
           unsubs.push(unsubDoc);

           // Listen for remote ICE
           const unsubIce = onSnapshot(answerCandidates, (snapshot) => {
             snapshot.docChanges().forEach((change) => {
               if (change.type === 'added') {
                 const candidate = new RTCIceCandidate(JSON.parse(change.doc.data().candidate));
                 pc.addIceCandidate(candidate);
               }
             });
           });
           unsubs.push(unsubIce);
           
        } else {
           // -------- I am Callee --------
           setStatus('Answering...');
           const callDoc = doc(db, 'calls', existingCallId);
           callDocRef.current = callDoc;
           
           const offerCandidates = collection(callDoc, 'callerCandidates');
           const answerCandidates = collection(callDoc, 'calleeCandidates');

           pc.onicecandidate = (event) => {
             if (event.candidate) {
               addDoc(answerCandidates, { candidate: JSON.stringify(event.candidate.toJSON()) });
             }
           };
           
           // Listen for caller's status (e.g. hangup)
           const unsubDoc = onSnapshot(callDoc, (snapshot) => {
               const data = snapshot.data();
               if (data?.status === 'ended') {
                  handleHangup();
               }
           });
           unsubs.push(unsubDoc);

           const callData = (await getDoc(callDoc)).data();
           if (callData?.offer) {
             const offerDescription = new RTCSessionDescription(JSON.parse(callData.offer));
             await pc.setRemoteDescription(offerDescription);

             const answerDescription = await pc.createAnswer();
             await pc.setLocalDescription(answerDescription);
  
             await updateDoc(callDoc, { answer: JSON.stringify(answerDescription), status: 'answered' });
             setStatus('Connected');
           }

           const unsubIce = onSnapshot(offerCandidates, (snapshot) => {
             snapshot.docChanges().forEach((change) => {
               if (change.type === 'added') {
                 const candidate = new RTCIceCandidate(JSON.parse(change.doc.data().candidate));
                 pc.addIceCandidate(candidate);
               }
             });
           });
           unsubs.push(unsubIce);
        }
      } catch (err) {
         console.error('Call setup failed', err);
         setStatus('Failed to setup call. Allow camera permissions.');
      }
    };
    
    setupCall();
    
    return () => {
      unsubs.forEach(u => u());
      if (callDocRef.current) {
         updateDoc(callDocRef.current, { status: 'ended' }).catch(()=> {}); // Cleanup
      }
      pcRef.current?.close();
      localStreamRef.current?.getTracks().forEach(t => t.stop());
    };
  }, []);

  const handleHangup = () => {
     if (callDocRef.current) {
         updateDoc(callDocRef.current, { status: 'ended' }).catch(()=>{});
     }
     pcRef.current?.close();
     localStreamRef.current?.getTracks().forEach(t => t.stop());
     onClose();
  };

  const toggleMic = () => {
    if (localStreamRef.current) {
       const audioTracks = localStreamRef.current.getAudioTracks();
       if (audioTracks[0]) {
         audioTracks[0].enabled = !micState;
         setMicState(!micState);
       }
    }
  };

  const toggleCam = () => {
    if (localStreamRef.current) {
       const videoTracks = localStreamRef.current.getVideoTracks();
       if (videoTracks[0]) {
         videoTracks[0].enabled = !camState;
         setCamState(!camState);
       }
    }
  };

  return (
    <div className="relative w-full h-full bg-gray-900 overflow-hidden text-white font-sans flex flex-col pt-12 text-center text-sm">
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 bg-black/40 px-4 py-1.5 rounded-full backdrop-blur-md border border-white/10 font-medium">
         {status}
      </div>

      <div className="flex-1 relative">
         {/* Remote Video (Full Screen) */}
         <video 
            ref={remoteVideoRef} 
            autoPlay 
            playsInline 
            className="w-full h-full object-cover bg-gray-900 border-none outline-none"
         />
         
         {/* Local Video (Floating PIP) */}
         <div className="absolute bottom-24 right-4 w-28 h-40 bg-gray-800 rounded-2xl overflow-hidden shadow-2xl border border-white/20 z-20">
           <video 
              ref={localVideoRef} 
              autoPlay 
              playsInline 
              muted 
              className="w-full h-full object-cover"
           />
         </div>
      </div>

      {/* Controls Container */}
      <div className="h-28 w-full bg-gradient-to-t from-black/90 to-transparent absolute bottom-0 z-30 flex items-center justify-center gap-6 pb-6 pt-10">
         <button onClick={toggleMic} className={`p-4 rounded-full transition-all ${micState ? 'bg-white/20 hover:bg-white/30 text-white backdrop-blur-md' : 'bg-red-500 text-white hover:bg-red-600 shadow-lg shadow-red-500/30'}`}>
            {micState ? <Mic size={24} /> : <MicOff size={24} />}
         </button>
         
         <button onClick={handleHangup} className="p-4 bg-red-500 hover:bg-red-600 text-white rounded-full transition-all shadow-lg shadow-red-500/30 scale-110">
            <PhoneOff size={28} />
         </button>

         <button onClick={toggleCam} className={`p-4 rounded-full transition-all ${camState ? 'bg-white/20 hover:bg-white/30 text-white backdrop-blur-md' : 'bg-red-500 text-white hover:bg-red-600 shadow-lg shadow-red-500/30'}`}>
            {camState ? <Video size={24} /> : <VideoOff size={24} />}
         </button>
      </div>
    </div>
  );
}
