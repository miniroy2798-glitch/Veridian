import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { db, logoutUser } from '../lib/firebase';
import { collection, query, getDocs, doc, getDoc, setDoc, serverTimestamp, where, onSnapshot, limit, updateDoc, arrayUnion } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { Search, LogOut, Plus, Users, UserPlus, UserCheck } from 'lucide-react';
import { generateGroupKey, exportKeyToBase64, encryptSymmetricKey } from '../lib/crypto';

interface ChatPreview {
  id: string;
  name?: string;
  isGroup?: boolean;
  participants: string[];
  lastMessagePreview?: string;
  lastMessageAt?: any;
  peerData?: UserProfile;
}

interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  publicKeyJwk?: string;
  contacts?: string[];
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [chats, setChats] = useState<ChatPreview[]>([]);
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState<'chats'|'contacts'|'find'>('chats');
  const [showProfile, setShowProfile] = useState(false);
  const [profileName, setProfileName] = useState(user?.displayName || '');
  const [profilePhoto, setProfilePhoto] = useState(user?.photoURL || '');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [myProfile, setMyProfile] = useState<UserProfile | null>(null);

  const [contactUsers, setContactUsers] = useState<UserProfile[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<UserProfile[]>([]);
  
  const [globalSearch, setGlobalSearch] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const saveProfile = async () => {
     if (!user) return;
     setIsSavingProfile(true);
     try {
       await setDoc(doc(db, 'users', user.uid), {
         displayName: profileName,
         photoURL: profilePhoto
       }, { merge: true });
       setShowProfile(false);
       window.location.reload(); // Refresh the auth state lightly
     } catch(e) {
       console.error("Failed to update profile", e);
     }
     setIsSavingProfile(false);
  };

  const handleProfilePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
     const file = e.target.files?.[0];
     if (!file) return;
     const reader = new FileReader();
     reader.onload = (ev) => {
        setProfilePhoto(ev.target?.result as string);
     }
     reader.readAsDataURL(file);
  };

  // Sync my profile
  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(doc(db, 'users', user.uid), (d) => {
       if (d.exists()) {
          setMyProfile(d.data() as UserProfile);
       }
    });
    return () => unsub();
  }, [user]);

  // Sync chats
  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user.uid)
    );
    const unsub = onSnapshot(q, async (snapshot) => {
      const fetchedChats: ChatPreview[] = [];
      for (const d of snapshot.docs) {
        const data = d.data();
        const chat: ChatPreview = {
          id: d.id,
          name: data.name,
          isGroup: data.isGroup,
          participants: data.participants,
          lastMessagePreview: data.lastMessagePreview,
          lastMessageAt: data.lastMessageAt
        };
        
        if (!chat.isGroup) {
          const peerId = data.participants.find((p: string) => p !== user.uid);
          if (peerId) {
             const peerDoc = await getDoc(doc(db, 'users', peerId));
             if (peerDoc.exists()) {
                chat.peerData = peerDoc.data() as UserProfile;
             }
          }
        }
        fetchedChats.push(chat);
      }
      fetchedChats.sort((a, b) => (b.lastMessageAt?.toMillis() || 0) - (a.lastMessageAt?.toMillis() || 0));
      setChats(fetchedChats);
    });
    return () => unsub();
  }, [user]);

  // Load contacts securely without fetching entire users collection
  useEffect(() => {
    if (tab !== 'contacts') return;
    const fetchContacts = async () => {
       if (!myProfile?.contacts?.length) {
          setContactUsers([]);
          return;
       }
       const fetched: UserProfile[] = [];
       // Max 100 contacts loading for performance
       for (const uid of myProfile.contacts.slice(0, 100)) {
          const d = await getDoc(doc(db, 'users', uid));
          if (d.exists()) {
             fetched.push(d.data() as UserProfile);
          }
       }
       // Sort contacts alphabetically
       fetched.sort((a, b) => a.displayName.localeCompare(b.displayName));
       setContactUsers(fetched);
    };
    fetchContacts();
  }, [tab, myProfile?.contacts]);

  const searchGlobalUsers = async () => {
    if (!globalSearch.trim() || !user) return;
    setIsSearching(true);
    setSearchResults([]);
    try {
      const trimmed = globalSearch.trim();
      const results: Record<string, UserProfile> = {};
      
      // Query by exact email
      const qEmail = query(collection(db, 'users'), where('email', '==', trimmed));
      const snapEmail = await getDocs(qEmail);
      snapEmail.forEach(d => {
         if (d.id !== user.uid) results[d.id] = d.data() as UserProfile;
      });

      // Query by display name prefix
      const qName = query(collection(db, 'users'), where('displayName', '>=', trimmed), where('displayName', '<=', trimmed + '\uf8ff'), limit(10));
      const snapName = await getDocs(qName);
      snapName.forEach(d => {
         if (d.id !== user.uid) results[d.id] = d.data() as UserProfile;
      });

      setSearchResults(Object.values(results));
    } catch(e) {
      console.error(e);
    }
    setIsSearching(false);
  };

  const addContact = async (peerId: string) => {
    if (!user) return;
    try {
       await updateDoc(doc(db, 'users', user.uid), {
          contacts: arrayUnion(peerId)
       });
       setTab('contacts');
    } catch(e) {
       console.error("Failed to add contact", e);
    }
  };

  const start1on1Chat = async (peer: UserProfile) => {
    if (!user) return;
    const sortedUids = [user.uid, peer.uid].sort();
    const chatId = `${sortedUids[0]}_${sortedUids[1]}`;
    
    const chatRef = doc(db, 'chats', chatId);
    const chatDoc = await getDoc(chatRef);
    if (!chatDoc.exists()) {
      await setDoc(chatRef, {
        participants: sortedUids,
        createdAt: serverTimestamp(),
      });
    }
    navigate(`/chat/${chatId}`);
  };

  const createGroupChat = async () => {
    if (!user || selectedUsers.length === 0) return;
    try {
       const groupName = prompt('Enter Group Name:') || 'New Group';
       const aesKey = await generateGroupKey();
       const groupKeys: Record<string, any> = {};
       
       const members = [user.uid, ...selectedUsers.map(u => u.uid)];
       
       // Process each member to securely deliver the group key
       for (const u of [{uid: user.uid}, ...selectedUsers]) {
          const peerDoc = await getDoc(doc(db, 'users', u.uid));
          if (peerDoc.exists() && peerDoc.data().publicKeyJwk) {
             const { deriveSharedKey } = await import('../lib/crypto');
             const sharedWithMember = await deriveSharedKey(peerDoc.data().publicKeyJwk);
             if (sharedWithMember) {
                const encryptedGroupKey = await encryptSymmetricKey(sharedWithMember, aesKey);
                groupKeys[u.uid] = encryptedGroupKey;
             }
          }
       }
       
       const groupRef = doc(collection(db, 'chats'));
       await setDoc(groupRef, {
         participants: members,
         isGroup: true,
         name: groupName,
         groupKeys,
         createdAt: serverTimestamp(),
         adminId: user.uid
       });
       
       navigate(`/chat/${groupRef.id}`);
    } catch(err) {
       console.error("Failed to create group", err);
    }
  };

  const filteredChats = chats.filter(c => {
     const name = c.isGroup ? c.name : c.peerData?.displayName;
     return name?.toLowerCase().includes(search.toLowerCase());
  });

  const filteredContacts = contactUsers.filter(u => u.displayName.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex-1 flex flex-col p-6 w-full max-w-2xl mx-auto h-[100dvh]">
      <div className="bg-white rounded-[32px] shadow-sm flex flex-col overflow-hidden h-full">
        <div className="p-8 pb-4 shrink-0">
          <div className="flex items-center justify-between mb-8">
            <h1 className="font-serif italic text-3xl text-[#5A5A40]">Veridian</h1>
            <div className="flex gap-2">
              <button onClick={() => setTab('chats')} className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${tab === 'chats' ? 'bg-[#5A5A40] text-white' : 'text-[#a8a79d] hover:bg-[#f5f5f0]'}`}>Chats</button>
              <button onClick={() => setTab('contacts')} className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${tab === 'contacts' ? 'bg-[#5A5A40] text-white' : 'text-[#a8a79d] hover:bg-[#f5f5f0]'}`}>Contacts</button>
              <button onClick={() => { setTab('find'); setGlobalSearch(''); setSearchResults([]); }} className={`px-4 py-1.5 rounded-full text-xs font-bold transition ${tab === 'find' ? 'bg-[#5A5A40] text-white' : 'text-[#a8a79d] hover:bg-[#f5f5f0]'}`}>Find</button>
              <button onClick={logoutUser} className="p-1 px-3 ml-2 text-[#a8a79d] hover:text-[#5A5A40] transition rounded-full hover:bg-[#f5f5f0]">
                <LogOut size={16} />
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-3 mb-6 cursor-pointer hover:bg-[#f5f5f0]/50 p-2 rounded-2xl transition" onClick={() => setShowProfile(true)}>
            {user?.photoURL ? (
              <img src={user.photoURL} alt="Avatar" className="w-10 h-10 rounded-full object-cover" />
            ) : (
              <div className="w-10 h-10 bg-[#5A5A40] border-2 border-white text-white rounded-full flex items-center justify-center font-bold shrink-0">
                {user?.displayName?.charAt(0) || 'U'}
              </div>
            )}
            <div className="flex-1">
              <p className="text-xs font-bold text-[#2d2d2a]">{user?.displayName}</p>
              <p className="text-[10px] text-[#8a9a5b] font-medium">Online • Edit Profile</p>
            </div>
            <div className="w-2 h-2 rounded-full bg-[#8a9a5b] mr-2"></div>
          </div>

          <div className="relative flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#a8a79d]" size={18} />
              <input
                type="text"
                placeholder={tab === 'chats' ? "Search conversations..." : tab === 'contacts' ? "Search contacts..." : "Search by email or name..."}
                value={tab === 'find' ? globalSearch : search}
                onChange={e => tab === 'find' ? setGlobalSearch(e.target.value) : setSearch(e.target.value)}
                onKeyDown={e => (e.key === 'Enter' && tab === 'find') && searchGlobalUsers()}
                className="w-full bg-[#f5f5f0] border-none rounded-full py-3 pr-5 pl-12 text-sm focus:ring-1 focus:ring-[#5A5A40] placeholder:text-[#a8a79d]"
              />
            </div>
            {tab === 'find' && (
               <button onClick={searchGlobalUsers} disabled={isSearching} className="bg-[#5A5A40] text-white px-6 py-3 rounded-full text-sm font-medium hover:bg-[#4a4a35] transition">
                 {isSearching ? '...' : 'Search'}
               </button>
            )}
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto px-4 space-y-2 py-4">
          {tab === 'chats' && (
            <>
              {filteredChats.map((c) => (
                <div key={c.id} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-[#f5f5f0]/50 cursor-pointer transition-colors" onClick={() => navigate(`/chat/${c.id}`)}>
                  {c.isGroup ? (
                    <div className="w-12 h-12 rounded-full bg-[#e8e8e0] text-[#5A5A40] flex items-center justify-center font-bold text-lg shrink-0">
                       <Users size={20} />
                    </div>
                  ) : c.peerData?.photoURL ? (
                    <img src={c.peerData.photoURL} alt="" className="w-12 h-12 rounded-full object-cover shrink-0" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-[#8a9a5b] flex items-center justify-center text-white font-bold text-lg shrink-0">
                      {c.peerData?.displayName?.charAt(0) || '?'}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-semibold text-sm truncate text-[#2d2d2a]">{c.isGroup ? c.name : c.peerData?.displayName}</h3>
                    </div>
                    <p className="text-xs text-[#8e8e8e] truncate">{c.isGroup ? 'Group Chat' : 'Encrypted Chat'}</p>
                  </div>
                </div>
              ))}
              {filteredChats.length === 0 && (
                <div className="text-center py-12 text-[#8e8e8e] text-sm">
                  No secure chats found. Start one from Contacts.
                </div>
              )}
            </>
          )}

          {tab === 'contacts' && (
            <>
              {selectedUsers.length > 0 && (
                <div className="px-4 py-2 border-b border-[#f5f5f0] mb-4 flex items-center justify-between">
                  <span className="text-xs font-bold text-[#5A5A40]">{selectedUsers.length} selected</span>
                  <button onClick={createGroupChat} className="bg-[#5A5A40] text-white px-4 py-1.5 rounded-full text-xs font-bold shadow-md hover:bg-[#4a4a35]">
                    Create Group
                  </button>
                </div>
              )}
              {filteredContacts.map((u) => {
                const isSelected = selectedUsers.find(su => su.uid === u.uid);
                return (
                  <div key={u.uid} className={`flex items-center gap-4 p-4 rounded-2xl cursor-pointer transition-colors ${isSelected ? 'bg-[#f5f5f0]' : 'hover:bg-[#f5f5f0]/50'}`} 
                       onClick={() => {
                          if (isSelected) {
                             setSelectedUsers(prev => prev.filter(p => p.uid !== u.uid));
                          } else {
                             setSelectedUsers(prev => [...prev, u]);
                          }
                       }}>
                    <div className="relative">
                      {u.photoURL ? (
                        <img src={u.photoURL} alt="" className="w-12 h-12 rounded-full object-cover shrink-0" />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-[#8a9a5b] flex items-center justify-center text-white font-bold text-lg shrink-0">
                          {u.displayName.charAt(0)}
                        </div>
                      )}
                      {isSelected && (
                         <div className="absolute -bottom-1 -right-1 bg-[#5A5A40] text-white rounded-full p-0.5 border-2 border-white">
                            <Plus size={12} />
                         </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <h3 className="font-semibold text-sm truncate text-[#2d2d2a]">{u.displayName}</h3>
                      </div>
                      <p className="text-xs text-[#8e8e8e] truncate">{u.email}</p>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); start1on1Chat(u); }} className="p-2 text-[#5A5A40] hover:bg-white rounded-full transition shadow-sm bg-[#f5f5f0]">
                       <UserPlus size={16} />
                    </button>
                  </div>
                );
              })}
              {filteredContacts.length === 0 && (
                <div className="text-center py-12 text-[#8e8e8e] text-sm flex flex-col items-center">
                  <p className="mb-4">No contacts found.</p>
                  <button onClick={() => setTab('find')} className="bg-[#5A5A40] text-white px-6 py-2 rounded-full font-medium">Find Friends</button>
                </div>
              )}
            </>
          )}

          {tab === 'find' && (
            <>
              {searchResults.map((u) => {
                const isContact = myProfile?.contacts?.includes(u.uid);
                return (
                  <div key={u.uid} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-[#f5f5f0]/50 transition-colors">
                    {u.photoURL ? (
                      <img src={u.photoURL} alt="" className="w-12 h-12 rounded-full object-cover shrink-0" />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-[#8a9a5b] flex items-center justify-center text-white font-bold text-lg shrink-0">
                        {u.displayName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <h3 className="font-semibold text-sm truncate text-[#2d2d2a]">{u.displayName}</h3>
                      </div>
                      <p className="text-xs text-[#8e8e8e] truncate">{u.email}</p>
                    </div>
                    {isContact ? (
                       <div className="p-2 text-[#8a9a5b] flex items-center gap-1.5 text-xs font-bold bg-[#f5f5f0] rounded-full px-3">
                         <UserCheck size={16} /> Added
                       </div>
                    ) : (
                       <button onClick={() => addContact(u.uid)} className="p-2 text-[#5A5A40] hover:bg-white rounded-full transition shadow-sm bg-[#f5f5f0] px-4 font-medium text-xs">
                         Add Contact
                       </button>
                    )}
                  </div>
                );
              })}
              {searchResults.length === 0 && !isSearching && globalSearch.length > 0 && (
                <div className="text-center py-12 text-[#8e8e8e] text-sm">
                  No users found. Try an exact email search or exact name prefix.
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {showProfile && (
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
           <div className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl">
              <h2 className="text-xl font-serif font-bold text-[#2d2d2a] mb-6">Profile Settings</h2>
              
              <div className="flex justify-center mb-6 relative">
                 {profilePhoto ? (
                    <img src={profilePhoto} className="w-24 h-24 rounded-full object-cover shadow-sm" alt="Profile" />
                 ) : (
                    <div className="w-24 h-24 bg-[#5A5A40] text-white font-bold text-3xl flex items-center justify-center rounded-full">
                       {profileName?.charAt(0) || 'U'}
                    </div>
                 )}
                 <label className="absolute bottom-0 right-1/4 bg-white p-2 rounded-full shadow-md cursor-pointer border border-[#f5f5f0] text-[#5A5A40] hover:bg-[#f5f5f0] transition">
                    <Plus size={16} />
                    <input type="file" accept="image/*" className="hidden" onChange={handleProfilePhotoSelect} />
                 </label>
              </div>

              <div className="space-y-4">
                 <div>
                    <label className="block text-xs font-bold text-[#8e8e8e] uppercase tracking-wider mb-2">Display Name</label>
                    <input 
                       type="text" 
                       value={profileName}
                       onChange={e => setProfileName(e.target.value)}
                       className="w-full bg-[#f5f5f0] border-none rounded-xl py-3 px-4 text-sm focus:ring-1 focus:ring-[#5A5A40]"
                    />
                 </div>
              </div>

              <div className="flex gap-3 justify-end mt-8">
                 <button onClick={() => setShowProfile(false)} className="px-5 py-2.5 rounded-full text-sm font-bold text-[#a8a79d] hover:bg-[#f5f5f0] transition">Cancel</button>
                 <button onClick={saveProfile} disabled={isSavingProfile} className="px-6 py-2.5 rounded-full text-sm font-bold bg-[#5A5A40] text-white hover:bg-[#4a4a35] transition flex items-center shadow-md">
                    {isSavingProfile ? 'Saving...' : 'Save Profile'}
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}
